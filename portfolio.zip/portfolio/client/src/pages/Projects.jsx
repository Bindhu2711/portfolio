import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import ProjectCard from "../components/ProjectCard";

const SAMPLE_PROJECTS = [
  {
    _id: "1", title: "E-Commerce Platform", featured: true,
    description: "Full-stack online store with cart, auth, and Stripe payments.",
    techStack: ["React", "Node.js", "MongoDB", "Stripe"],
    liveUrl: "https://example.com", githubUrl: "https://github.com",
  },
  {
    _id: "2", title: "Task Manager API",
    description: "RESTful API with JWT auth, rate limiting, and PostgreSQL.",
    techStack: ["Express", "PostgreSQL", "JWT", "Docker"],
    githubUrl: "https://github.com",
  },
  {
    _id: "3", title: "Real-time Chat App",
    description: "WebSocket-based chat with rooms, file uploads, and notifications.",
    techStack: ["React", "Socket.io", "Node.js", "MongoDB"],
    liveUrl: "https://example.com", githubUrl: "https://github.com",
  },
];

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get("/api/projects")
      .then((res) => setProjects(res.data.length ? res.data : SAMPLE_PROJECTS))
      .catch(() => setProjects(SAMPLE_PROJECTS))
      .finally(() => setLoading(false));
  }, []);

  return (
    <main style={{ padding: "8rem 2rem 5rem" }}>
      <div className="container">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <span className="section-label">Work</span>
          <h1 style={{ fontSize: "clamp(2.5rem, 5vw, 4rem)", fontWeight: 800, letterSpacing: "-0.03em", marginTop: "0.5rem" }}>
            Projects
          </h1>
          <p style={{ color: "var(--fg-muted)", marginTop: "1rem", maxWidth: 500 }}>
            A selection of things I've built — from side projects to production systems.
          </p>
        </motion.div>

        {loading ? (
          <div style={{ marginTop: "4rem", color: "var(--fg-muted)" }}>Loading...</div>
        ) : (
          <div style={{
            marginTop: "3rem",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
            gap: "1.5rem",
          }}>
            {projects.map((project, i) => (
              <ProjectCard key={project._id} project={project} index={i} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
