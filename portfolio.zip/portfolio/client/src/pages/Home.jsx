import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const skills = ["React", "Node.js", "MongoDB", "PostgreSQL", "Express", "Python", "Docker", "Git"];

export default function Home() {
  return (
    <main>
      {/* Hero */}
      <section style={{
        minHeight: "100vh", display: "flex", alignItems: "center",
        padding: "8rem 2rem 4rem", position: "relative", overflow: "hidden",
      }}>
        {/* Background grid */}
        <div style={{
          position: "absolute", inset: 0, zIndex: 0,
          backgroundImage: "linear-gradient(rgba(200,240,78,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(200,240,78,0.03) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }} />
        <div style={{ position: "absolute", top: "20%", right: "10%", width: 400, height: 400, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(200,240,78,0.06) 0%, transparent 70%)", zIndex: 0 }} />

        <div className="container" style={{ position: "relative", zIndex: 1, maxWidth: 900 }}>
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <span className="section-label">Available for hire</span>
            <h1 style={{ fontSize: "clamp(3rem, 8vw, 6rem)", fontWeight: 800, letterSpacing: "-0.03em", marginTop: "1rem", lineHeight: 1 }}>
              Building things<br />
              <span style={{ color: "var(--accent)" }}>for the web.</span>
            </h1>
            <p style={{ marginTop: "1.5rem", fontSize: "1.15rem", color: "var(--fg-muted)", maxWidth: 540, lineHeight: 1.7 }}>
              Full-stack developer crafting fast, scalable, and beautiful digital experiences.
              Passionate about clean code and thoughtful UI.
            </p>
            <div style={{ marginTop: "2.5rem", display: "flex", gap: "1rem", flexWrap: "wrap" }}>
              <Link to="/projects" style={{
                padding: "0.85rem 2rem", background: "var(--accent)", color: "#0a0a0a",
                borderRadius: 8, fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.95rem",
                transition: "opacity var(--transition)",
              }}>
                View Projects →
              </Link>
              <Link to="/contact" style={{
                padding: "0.85rem 2rem", border: "1px solid var(--border)", color: "var(--fg)",
                borderRadius: 8, fontFamily: "var(--font-display)", fontWeight: 600, fontSize: "0.95rem",
              }}>
                Get in touch
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Skills ticker */}
      <section style={{ padding: "2rem 0", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)", overflow: "hidden" }}>
        <motion.div
          animate={{ x: [0, -800] }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
          style={{ display: "flex", gap: "3rem", whiteSpace: "nowrap" }}
        >
          {[...skills, ...skills, ...skills].map((skill, i) => (
            <span key={i} style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.9rem",
              letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--fg-muted)" }}>
              {skill} <span style={{ color: "var(--accent)" }}>✦</span>
            </span>
          ))}
        </motion.div>
      </section>
    </main>
  );
}
