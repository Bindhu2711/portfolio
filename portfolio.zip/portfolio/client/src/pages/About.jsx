import { motion } from "framer-motion";

const stack = [
  { category: "Frontend", items: ["React", "HTML/CSS", "JavaScript", "Tailwind"] },
  { category: "Backend", items: ["Node.js", "Express", "Python", "Django"] },
  { category: "Database", items: ["MongoDB", "PostgreSQL", "MySQL", "Redis"] },
  { category: "DevOps", items: ["Docker", "Git", "Vercel", "Netlify"] },
];

export default function About() {
  return (
    <main style={{ padding: "8rem 2rem 5rem" }}>
      <div className="container" style={{ maxWidth: 800 }}>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <span className="section-label">About</span>
          <h1 style={{ fontSize: "clamp(2.5rem, 5vw, 4rem)", fontWeight: 800, letterSpacing: "-0.03em", marginTop: "0.5rem" }}>
            Hey, I'm a<br /><span style={{ color: "var(--accent)" }}>Full-Stack Dev.</span>
          </h1>
          <p style={{ marginTop: "2rem", fontSize: "1.1rem", color: "var(--fg-muted)", lineHeight: 1.8 }}>
            I build end-to-end web applications — from pixel-perfect UIs to scalable server architectures.
            I care about performance, accessibility, and shipping products that people actually enjoy using.
          </p>
          <p style={{ marginTop: "1rem", fontSize: "1.1rem", color: "var(--fg-muted)", lineHeight: 1.8 }}>
            When I'm not coding, I'm exploring new technologies, contributing to open source, or writing about what I've learned.
          </p>
        </motion.div>

        <div style={{ marginTop: "4rem" }}>
          <span className="section-label">Tech Stack</span>
          <div style={{ marginTop: "1.5rem", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: "1.5rem" }}>
            {stack.map(({ category, items }, i) => (
              <motion.div key={category}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "1.25rem" }}
              >
                <h3 style={{ fontFamily: "var(--font-display)", fontSize: "0.8rem", fontWeight: 700, letterSpacing: "0.1em",
                  textTransform: "uppercase", color: "var(--accent)", marginBottom: "0.75rem" }}>
                  {category}
                </h3>
                <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "0.4rem" }}>
                  {items.map((item) => (
                    <li key={item} style={{ fontSize: "0.9rem", color: "var(--fg-muted)" }}>{item}</li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
