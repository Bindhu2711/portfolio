import { useState } from "react";
import { motion } from "framer-motion";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState(null);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("sending");
    // Replace with your email service (EmailJS, Resend, etc.)
    setTimeout(() => setStatus("sent"), 1200);
  };

  const inputStyle = {
    width: "100%", padding: "0.85rem 1rem",
    background: "var(--bg-card)", border: "1px solid var(--border)",
    borderRadius: 8, color: "var(--fg)", fontFamily: "var(--font-body)", fontSize: "0.95rem",
    outline: "none", transition: "border-color var(--transition)",
  };

  return (
    <main style={{ padding: "8rem 2rem 5rem" }}>
      <div className="container" style={{ maxWidth: 600 }}>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <span className="section-label">Contact</span>
          <h1 style={{ fontSize: "clamp(2.5rem, 5vw, 4rem)", fontWeight: 800, letterSpacing: "-0.03em", marginTop: "0.5rem" }}>
            Let's talk.
          </h1>
          <p style={{ color: "var(--fg-muted)", marginTop: "1rem" }}>
            Have a project in mind or want to collaborate? Drop me a message.
          </p>
        </motion.div>

        {status === "sent" ? (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
            style={{ marginTop: "3rem", padding: "2rem", background: "rgba(200,240,78,0.06)",
              border: "1px solid rgba(200,240,78,0.2)", borderRadius: "var(--radius)", textAlign: "center" }}>
            <span style={{ fontSize: "2rem" }}>✓</span>
            <p style={{ marginTop: "0.75rem", fontFamily: "var(--font-display)", fontWeight: 700 }}>Message sent!</p>
            <p style={{ color: "var(--fg-muted)", marginTop: "0.25rem", fontSize: "0.9rem" }}>I'll get back to you soon.</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} style={{ marginTop: "3rem", display: "flex", flexDirection: "column", gap: "1.25rem" }}>
            <div>
              <label style={{ display: "block", marginBottom: "0.5rem", fontSize: "0.85rem",
                fontFamily: "var(--font-display)", fontWeight: 600, color: "var(--fg-muted)" }}>
                Name
              </label>
              <input name="name" value={form.name} onChange={handleChange} required
                placeholder="Your name" style={inputStyle} />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: "0.5rem", fontSize: "0.85rem",
                fontFamily: "var(--font-display)", fontWeight: 600, color: "var(--fg-muted)" }}>
                Email
              </label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required
                placeholder="you@example.com" style={inputStyle} />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: "0.5rem", fontSize: "0.85rem",
                fontFamily: "var(--font-display)", fontWeight: 600, color: "var(--fg-muted)" }}>
                Message
              </label>
              <textarea name="message" value={form.message} onChange={handleChange} required
                placeholder="Tell me about your project..." rows={6}
                style={{ ...inputStyle, resize: "vertical" }} />
            </div>
            <button type="submit" disabled={status === "sending"}
              style={{
                padding: "0.9rem 2rem", background: "var(--accent)", color: "#0a0a0a",
                borderRadius: 8, fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.95rem",
                opacity: status === "sending" ? 0.6 : 1, transition: "opacity var(--transition)", alignSelf: "flex-start",
              }}>
              {status === "sending" ? "Sending..." : "Send message →"}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
