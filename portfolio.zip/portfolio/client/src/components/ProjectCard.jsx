import { motion } from "framer-motion";

export default function ProjectCard({ project, index }) {
  const { title, description, techStack, liveUrl, githubUrl, imageUrl } = project;

  return (
    <motion.article
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      style={{
        background: "var(--bg-card)",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius)",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        transition: "border-color var(--transition), transform var(--transition)",
      }}
      whileHover={{ scale: 1.02, borderColor: "var(--accent)" }}
    >
      {imageUrl && (
        <div style={{ aspectRatio: "16/9", overflow: "hidden", background: "#1a1a1a" }}>
          <img src={imageUrl} alt={title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
      )}
      <div style={{ padding: "1.5rem", display: "flex", flexDirection: "column", gap: "0.75rem", flex: 1 }}>
        <h3 style={{ fontFamily: "var(--font-display)", fontSize: "1.15rem", fontWeight: 700 }}>{title}</h3>
        <p style={{ color: "var(--fg-muted)", fontSize: "0.9rem", lineHeight: 1.6, flex: 1 }}>{description}</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem" }}>
          {techStack?.map((tech) => (
            <span key={tech} style={{
              fontSize: "0.72rem", fontFamily: "var(--font-display)", fontWeight: 600,
              background: "rgba(200,240,78,0.08)", color: "var(--accent)",
              border: "1px solid rgba(200,240,78,0.2)", borderRadius: 4, padding: "2px 8px",
              letterSpacing: "0.04em",
            }}>
              {tech}
            </span>
          ))}
        </div>
        <div style={{ display: "flex", gap: "0.75rem", marginTop: "0.5rem" }}>
          {liveUrl && (
            <a href={liveUrl} target="_blank" rel="noopener noreferrer" style={{
              padding: "0.5rem 1rem", background: "var(--accent)", color: "#0a0a0a",
              borderRadius: 6, fontSize: "0.85rem", fontFamily: "var(--font-display)",
              fontWeight: 700, transition: "opacity var(--transition)",
            }}>
              Live ↗
            </a>
          )}
          {githubUrl && (
            <a href={githubUrl} target="_blank" rel="noopener noreferrer" style={{
              padding: "0.5rem 1rem", border: "1px solid var(--border)", color: "var(--fg)",
              borderRadius: 6, fontSize: "0.85rem", fontFamily: "var(--font-display)",
              fontWeight: 600, transition: "border-color var(--transition)",
            }}>
              GitHub
            </a>
          )}
        </div>
      </div>
    </motion.article>
  );
}
