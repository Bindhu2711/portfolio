import { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const links = [
  { to: "/", label: "Home" },
  { to: "/projects", label: "Projects" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        padding: "1.25rem 2rem",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: scrolled ? "rgba(10,10,10,0.9)" : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid var(--border)" : "none",
        transition: "all 0.3s ease",
      }}
    >
      <NavLink to="/" style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: "1.25rem", letterSpacing: "-0.02em" }}>
        <span style={{ color: "var(--accent)" }}>{"<"}</span>
        Dev
        <span style={{ color: "var(--accent)" }}>{"/>"}</span>
      </NavLink>

      {/* Desktop */}
      <ul style={{ display: "flex", gap: "2.5rem", listStyle: "none" }} className="desktop-nav">
        {links.map(({ to, label }) => (
          <li key={to}>
            <NavLink
              to={to}
              style={({ isActive }) => ({
                fontFamily: "var(--font-display)",
                fontWeight: 600,
                fontSize: "0.9rem",
                letterSpacing: "0.04em",
                color: isActive ? "var(--accent)" : "var(--fg-muted)",
                transition: "color var(--transition)",
              })}
            >
              {label}
            </NavLink>
          </li>
        ))}
      </ul>

      {/* Hamburger (mobile) */}
      <button
        onClick={() => setOpen(!open)}
        style={{ background: "none", display: "none", flexDirection: "column", gap: "5px", padding: "4px" }}
        className="hamburger"
        aria-label="Toggle menu"
      >
        {[0, 1, 2].map((i) => (
          <span key={i} style={{ width: 22, height: 2, background: "var(--fg)", display: "block", borderRadius: 2 }} />
        ))}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            style={{
              position: "fixed", top: 64, left: 0, right: 0, bottom: 0,
              background: "var(--bg)", display: "flex", flexDirection: "column",
              alignItems: "center", justifyContent: "center", gap: "2.5rem", zIndex: 99,
            }}
          >
            {links.map(({ to, label }) => (
              <NavLink key={to} to={to} onClick={() => setOpen(false)}
                style={({ isActive }) => ({
                  fontFamily: "var(--font-display)", fontWeight: 800, fontSize: "2.5rem",
                  color: isActive ? "var(--accent)" : "var(--fg)",
                })}
              >
                {label}
              </NavLink>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        @media (max-width: 640px) {
          .desktop-nav { display: none !important; }
          .hamburger { display: flex !important; }
        }
      `}</style>
    </motion.nav>
  );
}
